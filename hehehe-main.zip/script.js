const videoSources = [
  "https://v1.pinimg.com/videos/mc/720p/47/95/dc/4795dc2539e5175107bfce9eeda217cd.mp4",
  "https://motionbgs.com/media/923/itachi-and-kisame-in-the-rain.960x540.mp4",
  "https://motionbgs.com/media/5615/mob.960x540.mp4",
  "https://motionbgs.com/media/7778/saber-alter.960x540.mp4",
  "https://motionbgs.com/media/5969/goku-explosive-aura.960x540.mp4",
  "https://motionbgs.com/media/5623/shigeo-kageyama-cosmic.960x540.mp4"
];

function hashString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

fetch("https://ipapi.co/json")
  .then(res => res.json())
  .then(data => {
    const ip = data.ip || "0.0.0.0";
    const now = new Date();
    const seed = ip + now.toISOString().slice(0, 13);
    const videoId = hashString(seed) % videoSources.length;

    const bgSource = document.getElementById("bg-source");
    const bgVideo = document.getElementById("background-video");

    if (bgSource && bgVideo) {
      bgSource.src = videoSources[videoId];
      bgVideo.load();
    }
  })
  .catch(() => {
    const videoId = Math.floor(Math.random() * videoSources.length);
    const bgSource = document.getElementById("bg-source");
    const bgVideo = document.getElementById("background-video");

    if (bgSource && bgVideo) {
      bgSource.src = videoSources[videoId];
      bgVideo.load();
    }
  });